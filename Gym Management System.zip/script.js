// Firebase configuration (replace with your Firebase project config)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore(); // Firestore database instance
const auth = firebase.auth(); // Firebase Authentication instance

// DOM Elements
const adminLoginForm = document.getElementById("admin-login-form");
const memberLoginForm = document.getElementById("member-login-form");
const userLoginForm = document.getElementById("user-login-form");
const loginForm = document.getElementById("login-form");

// Admin Login functionality
adminLoginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("admin-email").value;
    const password = document.getElementById("admin-password").value;
    auth.signInWithEmailAndPassword(email, password)
        .then(() => {
            alert("Admin login successful!");
        })
        .catch((error) => {
            alert("Admin login failed: " + error.message);
        });
});

// Member Login functionality
memberLoginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("member-email").value;
    const password = document.getElementById("member-password").value;
    auth.signInWithEmailAndPassword(email, password)
        .then(() => {
            alert("Member login successful!");
        })
        .catch((error) => {
            alert("Member login failed: " + error.message);
        });
});

// User Login functionality
userLoginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("user-email").value;
    const password = document.getElementById("user-password").value;
    auth.signInWithEmailAndPassword(email, password)
        .then(() => {
            alert("User login successful!");
        })
        .catch((error) => {
            alert("User login failed: " + error.message);
        });
});

// General Login functionality
loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;
    auth.signInWithEmailAndPassword(email, password)
        .then(() => {
            alert("Login successful!");
        })
        .catch((error) => {
            alert("Login failed: " + error.message);
        });
});
